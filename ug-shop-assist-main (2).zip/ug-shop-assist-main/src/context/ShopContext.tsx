import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { toast } from "@/hooks/use-toast";
import { Debt, Expense, ExpenseCategory, ID, Product, Sale } from "@/store/types";
import { STORAGE_KEYS, genId, readStorage, writeStorage } from "@/store/storage";

// State shape
interface ShopState {
  products: Product[];
  sales: Sale[];
  expenses: Expense[];
  debts: Debt[];
}

// Input helpers
export type ProductInput = Omit<Product, "id" | "createdAt" | "updatedAt">;
export type ExpenseInput = Omit<Expense, "id" | "createdAt">;
export type DebtInput = Pick<Debt, "customerName" | "originalAmount" | "balance" | "dueDate"> & { saleId?: ID };
export type SaleItemInput = { productId: ID; qty: number };
export type SaleInput = {
  items: SaleItemInput[];
  isCredit?: boolean;
  isOnHold?: boolean;
  customerName?: string;
  dueDate?: string; // ISO
};

interface ShopContextValue extends ShopState {
  // products
  addProduct: (input: ProductInput) => void;
  updateProduct: (id: ID, patch: Partial<ProductInput>) => void;
  deleteProduct: (id: ID) => void;
  // sales
  recordSale: (input: SaleInput) => { ok: boolean; error?: string };
  updateSale: (id: ID, patch: Partial<SaleInput>) => { ok: boolean; error?: string };
  deleteSale: (id: ID) => void;
  // expenses
  addExpense: (input: ExpenseInput) => void;
  updateExpense: (id: ID, patch: Partial<ExpenseInput>) => void;
  deleteExpense: (id: ID) => void;
  // debts
  addDebt: (input: DebtInput) => void;
  recordPayment: (debtId: ID, amount: number, date?: string) => void;
  updateDebt: (id: ID, patch: Partial<DebtInput>) => void;
  deleteDebt: (id: ID) => void;
}

const ShopContext = createContext<ShopContextValue | null>(null);

export const ShopProvider = ({ children }: { children: React.ReactNode }) => {
  const [products, setProducts] = useState<Product[]>(() => readStorage<Product[]>(STORAGE_KEYS.products, []));
  const [sales, setSales] = useState<Sale[]>(() => readStorage<Sale[]>(STORAGE_KEYS.sales, []));
  const [expenses, setExpenses] = useState<Expense[]>(() => readStorage<Expense[]>(STORAGE_KEYS.expenses, []));
  const [debts, setDebts] = useState<Debt[]>(() => readStorage<Debt[]>(STORAGE_KEYS.debts, []));

  // persist
  useEffect(() => writeStorage(STORAGE_KEYS.products, products), [products]);
  useEffect(() => writeStorage(STORAGE_KEYS.sales, sales), [sales]);
  useEffect(() => writeStorage(STORAGE_KEYS.expenses, expenses), [expenses]);
  useEffect(() => writeStorage(STORAGE_KEYS.debts, debts), [debts]);

  // Products
  const addProduct = (input: ProductInput) => {
    const now = new Date().toISOString();
    const newP: Product = { id: genId("prd"), createdAt: now, updatedAt: now, ...input };
    setProducts((prev) => [newP, ...prev]);
    toast({ title: "Product added", description: `${newP.name} saved` });
  };

  const updateProduct = (id: ID, patch: Partial<ProductInput>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...patch, updatedAt: new Date().toISOString() } : p)),
    );
    toast({ title: "Product updated" });
  };

  const deleteProduct = (id: ID) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    toast({ title: "Product deleted" });
  };

  // Sales (reduces stock, may create debt)
  const recordSale: ShopContextValue["recordSale"] = (input) => {
    if (!input.items.length) return { ok: false, error: "No items in sale" };

    // verify stock
    const current = [...products];
    for (const { productId, qty } of input.items) {
      const p = current.find((x) => x.id === productId);
      if (!p) return { ok: false, error: "Product not found" };
      if (qty <= 0) return { ok: false, error: "Quantity must be greater than 0" };
      if (p.stock < qty) return { ok: false, error: `Insufficient stock for ${p.name}` };
    }

    // build sale items
    let total = 0;
    let cogsTotal = 0;
    const saleItems = input.items.map(({ productId, qty }) => {
      const p = products.find((x) => x.id === productId)!;
      const lineTotal = p.sellPrice * qty;
      const cogs = p.costPrice * qty;
      total += lineTotal;
      cogsTotal += cogs;
      return {
        productId,
        name: p.name,
        qty,
        sellPrice: p.sellPrice,
        costPrice: p.costPrice,
        lineTotal,
        cogs,
      };
    });

    const now = new Date().toISOString();
    const sale: Sale = {
      id: genId("sal"),
      items: saleItems,
      total,
      cogsTotal,
      isCredit: !!input.isCredit,
      isOnHold: !!input.isOnHold,
      customerName: input.customerName || undefined,
      createdAt: now,
    };

    // reduce stock only if not on hold
    if (!input.isOnHold) {
      setProducts((prev) =>
        prev.map((p) => {
          const si = input.items.find((x) => x.productId === p.id);
          if (!si) return p;
          return { ...p, stock: p.stock - si.qty, updatedAt: now };
        }),
      );
    }

    // add sale
    setSales((prev) => [sale, ...prev]);

    // create debt if credit and not on hold
    if (input.isCredit && !input.isOnHold) {
      const debt: Debt = {
        id: genId("debt"),
        customerName: input.customerName || "Customer",
        saleId: sale.id,
        originalAmount: total,
        balance: total,
        dueDate: input.dueDate,
        createdAt: now,
        payments: [],
      };
      setDebts((prev) => [debt, ...prev]);
      toast({ title: "Credit sale recorded", description: `Debt created for ${debt.customerName}` });
    } else if (input.isOnHold) {
      toast({ title: "Sale on hold", description: `Total ${total.toLocaleString()} - Stock reserved` });
    } else {
      toast({ title: "Sale recorded", description: `Total ${total.toLocaleString()}` });
    }

    return { ok: true };
  };

  const updateSale = (id: ID, patch: Partial<SaleInput>): { ok: boolean; error?: string } => {
    const existingSale = sales.find(s => s.id === id);
    if (!existingSale) return { ok: false, error: "Sale not found" };

    // Update the sale record
    setSales(prev => prev.map(s => s.id === id ? { 
      ...s, 
      isCredit: patch.isCredit !== undefined ? !!patch.isCredit : s.isCredit,
      isOnHold: patch.isOnHold !== undefined ? !!patch.isOnHold : s.isOnHold,
      customerName: patch.customerName || s.customerName 
    } : s));

    toast({ title: "Sale updated" });
    return { ok: true };
  };

  const deleteSale = (id: ID) => {
    setSales(prev => prev.filter(s => s.id !== id));
    toast({ title: "Sale deleted" });
  };

  // Expenses
  const addExpense = (input: ExpenseInput) => {
    const now = new Date().toISOString();
    const exp: Expense = { id: genId("exp"), createdAt: now, ...input };
    setExpenses((prev) => [exp, ...prev]);
    toast({ title: "Expense added" });
  };

  const updateExpense = (id: ID, patch: Partial<ExpenseInput>) => {
    setExpenses((prev) => prev.map((e) => (e.id === id ? { ...e, ...patch } : e)));
    toast({ title: "Expense updated" });
  };

  const deleteExpense = (id: ID) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    toast({ title: "Expense deleted" });
  };

  // Debts
  const addDebt = (input: DebtInput) => {
    const now = new Date().toISOString();
    const d: Debt = {
      id: genId("debt"),
      payments: [],
      createdAt: now,
      ...input,
    };
    setDebts((prev) => [d, ...prev]);
    toast({ title: "Debt added", description: `For ${d.customerName}` });
  };

  const recordPayment = (debtId: ID, amount: number, date?: string) => {
    if (amount <= 0) return;
    setDebts((prev) =>
      prev.map((d) => {
        if (d.id !== debtId) return d;
        const newBalance = Math.max(0, d.balance - amount);
        return {
          ...d,
          balance: newBalance,
          payments: [
            ...d.payments,
            { id: genId("pay"), amount, date: date || new Date().toISOString() },
          ],
        };
      }),
    );
    toast({ title: "Payment recorded" });
  };

  const updateDebt = (id: ID, patch: Partial<DebtInput>) => {
    setDebts((prev) => prev.map((d) => (d.id === id ? { ...d, ...patch } : d)));
    toast({ title: "Debt updated" });
  };

  const deleteDebt = (id: ID) => {
    setDebts((prev) => prev.filter((d) => d.id !== id));
    toast({ title: "Debt deleted" });
  };

  const value = useMemo<ShopContextValue>(() => ({
    products,
    sales,
    expenses,
    debts,
    addProduct,
    updateProduct,
    deleteProduct,
    recordSale,
    updateSale,
    deleteSale,
    addExpense,
    updateExpense,
    deleteExpense,
    addDebt,
    recordPayment,
    updateDebt,
    deleteDebt,
  }), [products, sales, expenses, debts]);

  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
};

export const useShop = () => {
  const ctx = useContext(ShopContext);
  if (!ctx) throw new Error("useShop must be used within ShopProvider");
  return ctx;
};
