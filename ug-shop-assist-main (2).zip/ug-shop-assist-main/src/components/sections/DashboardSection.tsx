import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Package, AlertTriangle, CreditCard, TrendingUp } from "lucide-react";
import { useShop } from "@/context/ShopContext";

export default function DashboardSection() {
  const { products, sales, debts, expenses } = useShop();

  const today = new Date();
  const todaySales = sales
    .filter((s) => new Date(s.createdAt).toDateString() === today.toDateString())
    .reduce((sum, s) => sum + s.total, 0);

  const lowStockItems = products.filter((p) => (p.reorderLevel ?? 5) >= p.stock).length;
  const pendingDebts = debts.reduce((sum, d) => sum + d.balance, 0);
  const month = today.getMonth();
  const monthlyRevenue = sales.filter((s) => new Date(s.createdAt).getMonth() === month).reduce((sum, s) => sum + s.total, 0);
  const monthlyExpenses = expenses.filter((e) => new Date(e.date).getMonth() === month).reduce((sum, e) => sum + e.amount, 0);

  const Stat = ({ title, value, icon }: { title: string; value: string; icon: React.ReactNode }) => (
    <Card className="bg-gradient-card shadow-card border-border/50">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-foreground">{value}</div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Stat title="Today's Sales" value={todaySales.toLocaleString()} icon={<DollarSign className="h-4 w-4 text-success" />} />
        <Stat title="Total Products" value={products.length.toString()} icon={<Package className="h-4 w-4 text-primary" />} />
        <Stat title="Low Stock" value={String(lowStockItems)} icon={<AlertTriangle className="h-4 w-4 text-warning" />} />
        <Stat title="Pending Debts" value={pendingDebts.toLocaleString()} icon={<CreditCard className="h-4 w-4 text-destructive" />} />
      </div>

      <Card className="bg-gradient-card shadow-card border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" /> Monthly Financial Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Revenue</p>
              <p className="text-2xl font-bold text-success">{monthlyRevenue.toLocaleString()}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Expenses</p>
              <p className="text-2xl font-bold text-destructive">{monthlyExpenses.toLocaleString()}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Profit</p>
              <p className="text-2xl font-bold text-primary">{(monthlyRevenue - monthlyExpenses).toLocaleString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Low stock list */}
      <Card className="bg-gradient-card shadow-card border-border/50">
        <CardHeader>
          <CardTitle>Low Stock Items</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {products.filter((p) => (p.reorderLevel ?? 5) >= p.stock).slice(0, 6).map((p) => (
            <div key={p.id} className="flex items-center justify-between">
              <span className="font-medium">{p.name}</span>
              <Badge className="bg-warning/10 text-warning border-warning/20">{p.stock} left</Badge>
            </div>
          ))}
          {products.filter((p) => (p.reorderLevel ?? 5) >= p.stock).length === 0 && (
            <p className="text-muted-foreground">All good! No low stock items.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
