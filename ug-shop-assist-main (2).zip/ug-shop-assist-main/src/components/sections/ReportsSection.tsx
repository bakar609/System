import { useMemo } from "react";
import { useShop } from "@/context/ShopContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { startOfDay, startOfWeek, startOfMonth, endOfDay, endOfWeek, endOfMonth, isWithinInterval } from "date-fns";
import * as XLSX from "xlsx";

export default function ReportsSection() {
  const { sales, expenses, debts, products } = useShop();

  const now = new Date();
  const ranges = {
    daily: { start: startOfDay(now), end: endOfDay(now) },
    weekly: { start: startOfWeek(now, { weekStartsOn: 1 }), end: endOfWeek(now, { weekStartsOn: 1 }) },
    monthly: { start: startOfMonth(now), end: endOfMonth(now) },
  } as const;

  const summary = useMemo(() => {
    const calc = (period: keyof typeof ranges) => {
      const r = ranges[period];
      const periodSales = sales.filter((s) => isWithinInterval(new Date(s.createdAt), r));
      const revenue = periodSales.reduce((sum, s) => sum + s.total, 0);
      const cogs = periodSales.reduce((sum, s) => sum + s.cogsTotal, 0);
      const periodExpenses = expenses.filter((e) => isWithinInterval(new Date(e.date), r));
      const expenseTotal = periodExpenses.reduce((sum, e) => sum + e.amount, 0);
      const profit = revenue - cogs - expenseTotal;
      return { revenue, cogs, expenseTotal, profit };
    };

    const outstandingDebts = debts.reduce((sum, d) => sum + d.balance, 0);

    return {
      daily: calc("daily"),
      weekly: calc("weekly"),
      monthly: calc("monthly"),
      outstandingDebts,
    };
  }, [sales, expenses, debts]);

  const Row = ({ label, value }: { label: string; value: number }) => (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-semibold">{value.toLocaleString()}</span>
    </div>
  );

  const downloadExcel = () => {
    const wb = XLSX.utils.book_new();
    
    // Sales sheet
    const salesData = sales.map(sale => ({
      Date: new Date(sale.createdAt).toLocaleDateString(),
      Items: sale.items.map(i => `${i.name} x${i.qty}`).join(', '),
      Total: sale.total,
      COGS: sale.cogsTotal,
      Type: sale.isOnHold ? 'On Hold' : sale.isCredit ? 'Credit' : 'Cash',
      Customer: sale.customerName || 'N/A'
    }));
    const salesSheet = XLSX.utils.json_to_sheet(salesData);
    XLSX.utils.book_append_sheet(wb, salesSheet, 'Sales');

    // Expenses sheet
    const expensesData = expenses.map(expense => ({
      Date: new Date(expense.date).toLocaleDateString(),
      Category: expense.category,
      Amount: expense.amount,
      Description: expense.description || 'N/A'
    }));
    const expensesSheet = XLSX.utils.json_to_sheet(expensesData);
    XLSX.utils.book_append_sheet(wb, expensesSheet, 'Expenses');

    // Products sheet
    const productsData = products.map(product => ({
      Name: product.name,
      SKU: product.sku || 'N/A',
      Category: product.category || 'N/A',
      'Cost Price': product.costPrice,
      'Sell Price': product.sellPrice,
      Stock: product.stock,
      'Reorder Level': product.reorderLevel || 'N/A'
    }));
    const productsSheet = XLSX.utils.json_to_sheet(productsData);
    XLSX.utils.book_append_sheet(wb, productsSheet, 'Products');

    // Debts sheet
    const debtsData = debts.map(debt => ({
      Customer: debt.customerName,
      'Original Amount': debt.originalAmount,
      Balance: debt.balance,
      'Due Date': debt.dueDate ? new Date(debt.dueDate).toLocaleDateString() : 'N/A',
      'Created Date': new Date(debt.createdAt).toLocaleDateString()
    }));
    const debtsSheet = XLSX.utils.json_to_sheet(debtsData);
    XLSX.utils.book_append_sheet(wb, debtsSheet, 'Debts');

    // Summary sheet
    const summaryData = [
      { Period: 'Daily', Revenue: summary.daily.revenue, COGS: summary.daily.cogs, Expenses: summary.daily.expenseTotal, Profit: summary.daily.profit },
      { Period: 'Weekly', Revenue: summary.weekly.revenue, COGS: summary.weekly.cogs, Expenses: summary.weekly.expenseTotal, Profit: summary.weekly.profit },
      { Period: 'Monthly', Revenue: summary.monthly.revenue, COGS: summary.monthly.cogs, Expenses: summary.monthly.expenseTotal, Profit: summary.monthly.profit }
    ];
    const summarySheet = XLSX.utils.json_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, summarySheet, 'Summary');

    XLSX.writeFile(wb, `shop-report-${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Reports</h2>
        <Button onClick={downloadExcel} className="bg-primary text-primary-foreground hover:bg-primary/90">
          Download Excel Report
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card className="bg-gradient-card shadow-card border-border/50">
        <CardHeader>
          <CardTitle>Daily Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Row label="Revenue" value={summary.daily.revenue} />
          <Row label="COGS" value={summary.daily.cogs} />
          <Row label="Expenses" value={summary.daily.expenseTotal} />
          <Row label="Profit" value={summary.daily.profit} />
        </CardContent>
      </Card>

      <Card className="bg-gradient-card shadow-card border-border/50">
        <CardHeader>
          <CardTitle>Weekly Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Row label="Revenue" value={summary.weekly.revenue} />
          <Row label="COGS" value={summary.weekly.cogs} />
          <Row label="Expenses" value={summary.weekly.expenseTotal} />
          <Row label="Profit" value={summary.weekly.profit} />
        </CardContent>
      </Card>

      <Card className="bg-gradient-card shadow-card border-border/50">
        <CardHeader>
          <CardTitle>Monthly Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Row label="Revenue" value={summary.monthly.revenue} />
          <Row label="COGS" value={summary.monthly.cogs} />
          <Row label="Expenses" value={summary.monthly.expenseTotal} />
          <Row label="Profit" value={summary.monthly.profit} />
        </CardContent>
      </Card>

      <Card className="bg-gradient-card shadow-card border-border/50 md:col-span-3">
        <CardHeader>
          <CardTitle>Outstanding Debts</CardTitle>
        </CardHeader>
        <CardContent>
          <Badge variant="secondary" className="text-lg p-2">{summary.outstandingDebts.toLocaleString()}</Badge>
        </CardContent>
      </Card>
      </div>
    </div>
  );
}
