import { useState } from "react";
import { useShop } from "@/context/ShopContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function DebtsSection() {
  const { debts, recordPayment, deleteDebt } = useShop();
  const [open, setOpen] = useState(false);
  const [selectedDebtId, setSelectedDebtId] = useState<string | null>(null);
  const [amount, setAmount] = useState<number>(0);

  const openPayment = (id: string) => { setSelectedDebtId(id); setOpen(true); setAmount(0); };
  const onPay = (e: React.FormEvent) => { e.preventDefault(); if (selectedDebtId) { recordPayment(selectedDebtId, amount); setOpen(false); } };

  return (
    <Card className="bg-gradient-card shadow-card border-border/50">
      <CardHeader>
        <CardTitle>Customer Debts</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Due</TableHead>
                <TableHead>Original</TableHead>
                <TableHead>Balance</TableHead>
                <TableHead>Status</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {debts.map((d) => {
                const status = d.balance <= 0 ? "Cleared" : d.dueDate && new Date(d.dueDate) < new Date() ? "Overdue" : "Pending";
                return (
                  <TableRow key={d.id}>
                    <TableCell className="font-medium">{d.customerName}</TableCell>
                    <TableCell>{new Date(d.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell>{d.dueDate ? new Date(d.dueDate).toLocaleDateString() : "—"}</TableCell>
                    <TableCell>{d.originalAmount.toLocaleString()}</TableCell>
                    <TableCell>{d.balance.toLocaleString()}</TableCell>
                    <TableCell>
                      {status === "Cleared" ? (
                        <Badge variant="secondary">Cleared</Badge>
                      ) : status === "Overdue" ? (
                        <Badge variant="destructive">Overdue</Badge>
                      ) : (
                        <Badge className="bg-warning/10 text-warning border-warning/20">Pending</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex gap-2 justify-end">
                        <Button size="sm" variant="secondary" onClick={() => openPayment(d.id)} disabled={d.balance <= 0}>Record Payment</Button>
                        <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteDebt(d.id)}>Delete</Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
              {debts.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground">No customer debts recorded.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Record Payment</DialogTitle>
            </DialogHeader>
            <form onSubmit={onPay} className="grid gap-4">
              <div className="grid gap-2">
                <Label>Amount</Label>
                <Input type="number" min={0} value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="secondary" onClick={() => setOpen(false)}>Cancel</Button>
                <Button type="submit">Save</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
