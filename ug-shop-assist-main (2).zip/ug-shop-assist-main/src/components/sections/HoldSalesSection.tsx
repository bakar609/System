import { useState } from "react";
import { useShop } from "@/context/ShopContext";
import { Sale } from "@/store/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Pencil, Trash2, Play } from "lucide-react";

export default function HoldSalesSection() {
  const { sales, updateSale, deleteSale } = useShop();
  const [editingSale, setEditingSale] = useState<Sale | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ isCredit: false, customerName: "" });

  const holdSales = sales.filter(sale => sale.isOnHold);

  const processHoldSale = (sale: Sale) => {
    const result = updateSale(sale.id, { isOnHold: false, isCredit: form.isCredit, customerName: form.customerName });
    if (result.ok) {
      setDialogOpen(false);
      setEditingSale(null);
      setForm({ isCredit: false, customerName: "" });
    }
  };

  const openEditDialog = (sale: Sale) => {
    setEditingSale(sale);
    setForm({ isCredit: sale.isCredit, customerName: sale.customerName || "" });
    setDialogOpen(true);
  };

  return (
    <Card className="bg-gradient-card shadow-card border-border/50">
      <CardHeader>
        <CardTitle>Hold Sales ({holdSales.length})</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Items</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {holdSales.map((sale) => (
                <TableRow key={sale.id}>
                  <TableCell>{new Date(sale.createdAt).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <div className="max-w-xs truncate">
                      {sale.items.map(i => `${i.name} x${i.qty}`).join(", ")}
                    </div>
                  </TableCell>
                  <TableCell className="font-semibold">UGX {sale.total.toLocaleString('en-UG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</TableCell>
                  <TableCell>
                    {sale.customerName ? (
                      <Badge variant="secondary">{sale.customerName}</Badge>
                    ) : (
                      <span className="text-muted-foreground">No customer</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button size="sm" variant="ghost" onClick={() => openEditDialog(sale)}>
                        <Play className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteSale(sale.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {holdSales.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground">
                    No hold sales. Sales marked as "Hold" will appear here.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Process Hold Sale</DialogTitle>
            </DialogHeader>
            {editingSale && (
              <div className="space-y-4">
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium">Sale Details</h4>
                  <p className="text-sm text-muted-foreground">
                    Items: {editingSale.items.map(i => `${i.name} x${i.qty}`).join(", ")}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Total: UGX {editingSale.total.toLocaleString('en-UG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </div>
                
                <div className="flex items-center gap-2">
                  <Label>Process as Credit Sale</Label>
                  <Switch 
                    checked={form.isCredit} 
                    onCheckedChange={(checked) => setForm(prev => ({ ...prev, isCredit: checked }))} 
                  />
                </div>

                {form.isCredit && (
                  <div className="grid gap-2">
                    <Label>Customer Name</Label>
                    <Input 
                      value={form.customerName} 
                      onChange={(e) => setForm(prev => ({ ...prev, customerName: e.target.value }))}
                      placeholder="Enter customer name"
                    />
                  </div>
                )}

                <div className="flex justify-end gap-2">
                  <Button variant="secondary" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => processHoldSale(editingSale)}>
                    Process Sale
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}