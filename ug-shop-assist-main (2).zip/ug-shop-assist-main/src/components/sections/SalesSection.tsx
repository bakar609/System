import { useMemo, useState } from "react";
import { useShop } from "@/context/ShopContext";
import { Sale } from "@/store/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Trash2, Printer } from "lucide-react";
import Receipt from "@/components/Receipt";

export default function SalesSection() {
  const { products, recordSale, sales } = useShop();
  const [items, setItems] = useState<{ productId: string; qty: number }[]>([]);
  const [isCredit, setIsCredit] = useState(false);
  const [isOnHold, setIsOnHold] = useState(false);
  const [customerName, setCustomerName] = useState("");
  const [dueDate, setDueDate] = useState<string>("");
  const [showReceipt, setShowReceipt] = useState<Sale | null>(null);

  const productMap = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);

  const addItem = () => setItems((prev) => [...prev, { productId: products[0]?.id || "", qty: 1 }]);
  const removeItem = (idx: number) => setItems((prev) => prev.filter((_, i) => i !== idx));
  const updateItem = (idx: number, patch: Partial<{ productId: string; qty: number }>) =>
    setItems((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));

  const totals = useMemo(() => {
    let total = 0;
    let valid = true;
    for (const it of items) {
      const p = productMap.get(it.productId);
      if (!p) { valid = false; continue; }
      total += p.sellPrice * (it.qty || 0);
    }
    return { total, valid };
  }, [items, productMap]);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = recordSale({ 
      items, 
      isCredit, 
      isOnHold,
      customerName: isCredit ? customerName : undefined, 
      dueDate: isCredit ? dueDate : undefined 
    });
    if (res.ok) {
      // For completed sales (non-hold), find the sale in the sales array to show receipt
      if (!isOnHold) {
        // Since recordSale doesn't return the sale object, we'll use the most recent sale
        setTimeout(() => {
          const latestSale = sales[0]; // Assuming sales are ordered by creation date
          if (latestSale) {
            setShowReceipt(latestSale);
          }
        }, 100);
      }
      
      setItems([]);
      setIsCredit(false);
      setIsOnHold(false);
      setCustomerName("");
      setDueDate("");
    }
  };

  return (
    <Card className="bg-gradient-card shadow-card border-border/50">
      <CardHeader>
        <CardTitle>Record Sale</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={onSubmit} className="space-y-6">
          <div className="flex items-center justify-between">
            <Button type="button" onClick={addItem} className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" /> Add Item
            </Button>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Label>Credit Sale</Label>
                <Switch checked={isCredit} onCheckedChange={setIsCredit} />
              </div>
              <div className="flex items-center gap-2">
                <Label>Hold Sale</Label>
                <Switch checked={isOnHold} onCheckedChange={setIsOnHold} />
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Available</TableHead>
                  <TableHead>Qty</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((it, idx) => {
                  const p = productMap.get(it.productId);
                  const lineTotal = p ? p.sellPrice * (it.qty || 0) : 0;
                  return (
                    <TableRow key={idx}>
                      <TableCell className="min-w-[220px]">
                        <Select value={it.productId} onValueChange={(v) => updateItem(idx, { productId: v })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select product" />
                          </SelectTrigger>
                          <SelectContent className="bg-card">
                            {products.map((pr) => (
                              <SelectItem key={pr.id} value={pr.id}>{pr.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>UGX {p?.sellPrice.toLocaleString('en-UG', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) ?? "-"}</TableCell>
                      <TableCell>
                        <Badge variant={p && p.stock > 0 ? "secondary" : "destructive"}>{p?.stock ?? 0}</Badge>
                      </TableCell>
                      <TableCell className="min-w-[120px]">
                        <Input type="number" min={1} value={it.qty} onChange={(e) => updateItem(idx, { qty: Number(e.target.value) })} />
                      </TableCell>
                      <TableCell>UGX {lineTotal.toLocaleString('en-UG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</TableCell>
                      <TableCell className="text-right">
                        <Button type="button" variant="ghost" onClick={() => removeItem(idx)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {items.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">No items. Add items to begin.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          {isCredit && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>Customer Name</Label>
                <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="e.g., John Okello" />
              </div>
              <div className="grid gap-2">
                <Label>Payment Due Date</Label>
                <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </div>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="text-lg font-medium">Total: UGX {totals.total.toLocaleString('en-UG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            <Button type="submit" disabled={!totals.valid || items.length === 0}>
              {isOnHold ? "Hold Sale" : "Save Sale"}
            </Button>
          </div>
        </form>

        {/* Recent sales */}
        <div className="space-y-2">
          <h3 className="text-sm uppercase tracking-wide text-muted-foreground">Recent Sales</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sales.slice(0, 5).map((s) => (
                  <TableRow key={s.id}>
                    <TableCell>{new Date(s.createdAt).toLocaleString()}</TableCell>
                    <TableCell>{s.items.map((i) => `${i.name} x${i.qty}`).join(", ")}</TableCell>
                    <TableCell>UGX {s.total.toLocaleString('en-UG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</TableCell>
                    <TableCell>
                      {s.isOnHold ? (
                        <Badge variant="outline">On Hold</Badge>
                      ) : s.isCredit ? (
                        <Badge variant="destructive">Credit</Badge>
                      ) : (
                        <Badge variant="secondary">Cash</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {!s.isOnHold && (
                        <Button size="sm" variant="ghost" onClick={() => setShowReceipt(s)}>
                          <Printer className="w-4 h-4" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
                {sales.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground">No sales recorded yet.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>

        {/* Receipt Modal */}
        {showReceipt && (
          <Receipt sale={showReceipt} onClose={() => setShowReceipt(null)} />
        )}
      </CardContent>
    </Card>
  );
}
