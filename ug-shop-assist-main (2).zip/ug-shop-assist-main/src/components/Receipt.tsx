import { Sale } from "@/store/types";

interface ReceiptProps {
  sale: Sale;
  onClose?: () => void;
}

export default function Receipt({ sale, onClose }: ReceiptProps) {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 print:bg-white print:relative print:inset-auto print:flex-none">
      <div className="bg-white max-w-md w-full mx-4 print:max-w-none print:mx-0 print:shadow-none shadow-lg">
        {/* Receipt Header */}
        <div className="p-6 print:p-4 text-center border-b">
          <h1 className="text-xl font-bold">Your Shop Name</h1>
          <p className="text-sm text-gray-600">Shop Address</p>
          <p className="text-sm text-gray-600">Tel: +256 XXX XXX XXX</p>
        </div>

        {/* Receipt Content */}
        <div className="p-6 print:p-4">
          <div className="text-center mb-4">
            <h2 className="text-lg font-semibold">SALES RECEIPT</h2>
            <p className="text-sm text-gray-600">Receipt #: {sale.id.slice(-8).toUpperCase()}</p>
            <p className="text-sm text-gray-600">Date: {new Date(sale.createdAt).toLocaleDateString('en-UG')} {new Date(sale.createdAt).toLocaleTimeString('en-UG')}</p>
          </div>

          {sale.customerName && (
            <div className="mb-4">
              <p className="text-sm"><strong>Customer:</strong> {sale.customerName}</p>
            </div>
          )}

          {/* Items */}
          <div className="border-b border-gray-300 mb-4">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-1">Item</th>
                  <th className="text-center py-1">Qty</th>
                  <th className="text-right py-1">Price</th>
                  <th className="text-right py-1">Total</th>
                </tr>
              </thead>
              <tbody>
                {sale.items.map((item, index) => (
                  <tr key={index}>
                    <td className="py-1">{item.name}</td>
                    <td className="text-center py-1">{item.qty}</td>
                    <td className="text-right py-1">UGX {item.sellPrice.toLocaleString('en-UG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                    <td className="text-right py-1">UGX {item.lineTotal.toLocaleString('en-UG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Total */}
          <div className="text-right mb-4">
            <p className="text-lg font-bold">TOTAL: UGX {sale.total.toLocaleString('en-UG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
            {sale.isCredit && (
              <p className="text-sm text-red-600 font-medium">CREDIT SALE</p>
            )}
          </div>

          {/* Footer */}
          <div className="text-center text-xs text-gray-500 border-t pt-4">
            <p>Thank you for your business!</p>
            <p>Goods sold are not returnable</p>
          </div>
        </div>

        {/* Print Buttons - Hidden during print */}
        <div className="print:hidden p-6 pt-0 flex gap-2 justify-center">
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Print Receipt
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
            >
              Close
            </button>
          )}
        </div>
      </div>
    </div>
  );
}