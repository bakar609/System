export type ID = string;

export type Product = {
  id: ID;
  name: string;
  sku?: string;
  category?: string;
  costPrice: number;
  sellPrice: number;
  stock: number;
  reorderLevel?: number;
  createdAt: string;
  updatedAt: string;
};

export type SaleItem = {
  productId: ID;
  name: string; // snapshot of name at sale time
  qty: number;
  sellPrice: number; // snapshot of price at sale time
  costPrice: number; // snapshot of cost at sale time
  lineTotal: number; // qty * sellPrice
  cogs: number; // qty * costPrice
};

export type Sale = {
  id: ID;
  items: SaleItem[];
  total: number;
  cogsTotal: number;
  isCredit: boolean;
  isOnHold: boolean;
  customerName?: string;
  createdAt: string; // ISO date
};

export type ExpenseCategory = "Rent" | "Utilities" | "Wages" | "Transport" | "Other";

export type Expense = {
  id: ID;
  category: ExpenseCategory;
  amount: number;
  description?: string;
  date: string; // ISO date
  createdAt: string;
};

export type Payment = {
  id: ID;
  amount: number;
  date: string; // ISO date
};

export type Debt = {
  id: ID;
  customerName: string;
  saleId?: ID; // linked sale if from credit sale
  originalAmount: number;
  balance: number;
  dueDate?: string; // ISO date
  createdAt: string;
  payments: Payment[];
};
