import { useState } from "react";
import { ShopProvider } from "@/context/ShopContext";
import DashboardSection from "@/components/sections/DashboardSection";
import ProductsSection from "@/components/sections/ProductsSection";
import SalesSection from "@/components/sections/SalesSection";
import HoldSalesSection from "@/components/sections/HoldSalesSection";
import ExpensesSection from "@/components/sections/ExpensesSection";
import DebtsSection from "@/components/sections/DebtsSection";
import ReportsSection from "@/components/sections/ReportsSection";
import { Button } from "@/components/ui/button";
import { BarChart3, Package, ShoppingCart, FileText, Users, LayoutDashboard, Clock } from "lucide-react";

const Index = () => {
  const [active, setActive] = useState<"dashboard" | "products" | "sales" | "hold" | "expenses" | "debts" | "reports">("dashboard");

  const Nav = () => (
    <div className="flex flex-wrap gap-2 mb-8 p-1 bg-muted rounded-lg">
      {[
        { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
        { id: "products", label: "Products", icon: Package },
        { id: "sales", label: "Sales", icon: ShoppingCart },
        { id: "hold", label: "Hold Sales", icon: Clock },
        { id: "expenses", label: "Expenses", icon: FileText },
        { id: "debts", label: "Customer Debts", icon: Users },
        { id: "reports", label: "Reports", icon: BarChart3 },
      ].map((tab) => {
        const Icon = tab.icon;
        const selected = active === (tab.id as typeof active);
        return (
          <Button key={tab.id} variant={selected ? "default" : "ghost"} onClick={() => setActive(tab.id as typeof active)} className={selected ? "bg-primary text-primary-foreground shadow-soft" : "hover:bg-accent"}>
            <Icon className="w-4 h-4 mr-2" /> {tab.label}
          </Button>
        );
      })}
    </div>
  );

  return (
    <ShopProvider>
      <main className="min-h-screen bg-background">
        <header className="bg-card border-b border-border shadow-card">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <h1 className="text-xl font-bold bg-gradient-primary bg-clip-text text-transparent">ShopManager</h1>
            <p className="text-sm text-muted-foreground">Simple shop management for Ugandan retail</p>
          </div>
        </header>
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Nav />
          {active === "dashboard" && <DashboardSection />}
          {active === "products" && <ProductsSection />}
          {active === "sales" && <SalesSection />}
          {active === "hold" && <HoldSalesSection />}
          {active === "expenses" && <ExpensesSection />}
          {active === "debts" && <DebtsSection />}
          {active === "reports" && <ReportsSection />}
        </section>
      </main>
    </ShopProvider>
  );
};

export default Index;
